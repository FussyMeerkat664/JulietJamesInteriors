

<div class="container-fluid">
  <div class="row">
    <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block sidebar collapse" style="background-color: #282B4A;">
      <div class="position-sticky">
      <!-- <a class="navbar-brand" href="#"><img src="../Assets/Images/Asset_2.svg" style="width: 200px;" alt=""></a> -->
        <hr class="text-dark fs-2">
      <div class="flex-shrink-0 p-3" style="width: 280px;">
      
    <ul class="list-unstyled ps-0">
      <li class="mb-1">
        <i class="text-white fs-5 fa-solid fa-gauge"></i>
        <a class="btn btn-toggle align-items-center rounded p-2" href="dashboard.php">
          <strong class="h5  border-3 p-0 m-0" style="color:white;">Dashboard</strong>
        </a>
      </li>
      <li class="mb-1">
       <i class="text-white fs-5 fa-solid fa-users"></i>
        <a class="btn btn-toggle align-items-center rounded p-2" style="color:white;" href="manage_users.php">
        Manage Users<strong class="h6 p-0 m-0"></strong>
        </a>
      </li>

      <li class="mb-1">
       <i class="text-white fs-5 fa-solid fa-users"></i>
        <a class="btn btn-toggle align-items-center rounded p-2" style="color:white;" href="manage_product.php">
        Manage Product<strong class="h6 p-0 m-0"></strong>
        </a>
      </li>

      <li class="mb-1">
        <i class="text-white fs-5 fa fa-list-alt"></i>
        <a class="btn btn-toggle align-items-center rounded p-2" style="color:white;" href="manage_category.php">
        Manage Category<strong class="h6 p-0 m-0"></strong>
        </a>
      </li>
      <li class="mb-1">
        <i class="text-white fs-5 fa-solid fa-user-tie"></i>
        <a class="btn btn-toggle align-items-center rounded p-2" style="color:white;" href="manage_schedule.php">
      Manage Schedule<strong class="h6 p-0 m-0"></strong>
        </a>
      </li>
      <li class="mb-1">
        <i class="text-white fs-5 fa-solid fa-lock"></i>
        <a class="btn btn-toggle align-items-center rounded p-2" style="color:white;" href="manage_privacy.php">
        Privacy & Policy<strong class="h6 p-0 m-0"></strong>
        </a>
      </li>
      <li class="mb-1">
        <i class="text-white fs-5 fa-solid fa-scroll"></i>
        <a class="btn btn-toggle align-items-center rounded p-2" style="color:white;" href="manage_term.php">
        Term & Conditions<strong class="h6 p-0 m-0"></strong>
        </a>
      </li>
  
    </ul>
  </div>
</div>
</nav>